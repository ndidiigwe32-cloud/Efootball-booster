# eFootball Booster for Android

A lightweight Android game-launch helper focused on eFootball. It does not require root and does not pretend to change Android kernel/GPU settings it cannot control.

## Included
- One-tap eFootball launch
- Lightweight booster UI
- Quick network settings
- Quick battery settings
- Safe, no-root approach

## Build
Open this folder in Android Studio and build the debug APK.

Note: Android does not allow an ordinary app to freely force-stop other apps or magically increase network speed without privileged/root access. This project therefore focuses on safe actions that can actually be performed on normal phones.
