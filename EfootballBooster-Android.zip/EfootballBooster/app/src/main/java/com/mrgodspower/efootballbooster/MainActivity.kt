package com.mrgodspower.efootballbooster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color

class MainActivity : android.app.Activity() {
    private val green = Color.rgb(56,211,159)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,30,28,24); setBackgroundColor(Color.rgb(11,15,20)) }
        val title=TextView(this).apply { text="eFootball Booster"; textSize=28f; setTextColor(Color.WHITE); setTypeface(null,1) }
        val sub=TextView(this).apply { text="Game-focused performance helper"; textSize=15f; setTextColor(Color.LTGRAY); setPadding(0,6,0,24) }
        root.addView(title); root.addView(sub)
        val status=TextView(this).apply { text="READY • Safe mode"; textSize=16f; setTextColor(green); setPadding(18,18,18,18); setBackgroundColor(Color.rgb(21,27,34)) }
        root.addView(status, LinearLayout.LayoutParams(-1,-2))
        val boost=Button(this).apply { text="BOOST & LAUNCH eFOOTBALL"; textSize=16f; setOnClickListener { launchGame(status) } }
        root.addView(boost, LinearLayout.LayoutParams(-1,60).apply{setMargins(0,24,0,12)})
        val tips=TextView(this).apply { text="BOOST actions\n• Opens eFootball directly\n• Keeps this booster lightweight\n• Provides quick network/device settings\n\nFor lower ping: use a stable Wi‑Fi/4G connection and stop downloads while playing."; textSize=15f; setTextColor(Color.LTGRAY); setPadding(8,18,8,18) }
        root.addView(tips)
        val net=Button(this).apply { text="OPEN NETWORK SETTINGS"; setOnClickListener { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } }
        root.addView(net)
        val batt=Button(this).apply { text="OPEN BATTERY SETTINGS"; setOnClickListener { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } }
        root.addView(batt)
        setContentView(root)
    }
    private fun launchGame(status: TextView) {
        val candidates=listOf("com.konami.pesam","jp.konami.pesam")
        var launched=false
        for (pkg in candidates) { val i=packageManager.getLaunchIntentForPackage(pkg); if(i!=null){ status.text="BOOST ACTIVE • Launching eFootball"; startActivity(i); launched=true; break } }
        if(!launched){ status.text="eFootball not found • Install eFootball first"; Toast.makeText(this,"eFootball app not found",Toast.LENGTH_LONG).show() }
    }
}
